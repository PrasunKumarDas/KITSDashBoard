'use strict';

const SetupEndpoint = require('./setup/');

module.exports = SetupEndpoint({
    name: 'public/request-password-reset-journey/landing',
    urls: [
        {
            requests: [{
                method: 'POST',
                response: '/response-files/public/request-password-reset-journey/landing.json'
            }]
        }
    ]
});
