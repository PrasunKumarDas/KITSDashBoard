'use strict';

const SetupEndpoint = require('./setup/');

module.exports = SetupEndpoint({
    name: 'public/breadcrumb',
    urls: [
        {
            
            requests: [{
                method: 'POST',
                response: '/response-files/public/breadcrumb.json'
            }]
        }
    ]
});
