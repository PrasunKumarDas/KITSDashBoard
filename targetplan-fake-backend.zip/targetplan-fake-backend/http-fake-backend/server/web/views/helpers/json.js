'use strict';

/**
 * Returns the given object as string representation.
 */

module.exports = function (object) {

    return JSON.stringify(object);
};
